import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import os
from datetime import datetime, timezone
from passlib.context import CryptContext
import uuid

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

mongo_url = "mongodb://localhost:27017"
client = AsyncIOMotorClient(mongo_url)
db = client["supermarket_db"]

async def seed_data():
    print("🌱 Starting database seeding...")
    
    # Clear existing data
    await db.users.delete_many({})
    await db.products.delete_many({})
    await db.categories.delete_many({})
    await db.orders.delete_many({})
    await db.reviews.delete_many({})
    print("✅ Cleared existing data")
    
    # Create admin user
    admin = {
        "id": str(uuid.uuid4()),
        "email": "admin@freshmart.com",
        "password": pwd_context.hash("admin123"),
        "name": "Admin User",
        "role": "admin",
        "phone": "+91-9876543210",
        "addresses": [],
        "wishlist": [],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.users.insert_one(admin)
    print(f"✅ Created admin user: {admin['email']} / admin123")
    
    # Create test user
    user = {
        "id": str(uuid.uuid4()),
        "email": "user@test.com",
        "password": pwd_context.hash("user123"),
        "name": "Test User",
        "role": "user",
        "phone": "+91-9876543211",
        "addresses": [],
        "wishlist": [],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.users.insert_one(user)
    print(f"✅ Created test user: {user['email']} / user123")
    
    # Create categories
    categories = [
        {"id": str(uuid.uuid4()), "name": "Groceries", "description": "Daily essentials and food items"},
        {"id": str(uuid.uuid4()), "name": "Fruits & Vegetables", "description": "Fresh produce delivered daily"},
        {"id": str(uuid.uuid4()), "name": "Dairy Products", "description": "Milk, cheese, and dairy items"},
        {"id": str(uuid.uuid4()), "name": "Beverages", "description": "Drinks, juices, and refreshments"},
        {"id": str(uuid.uuid4()), "name": "Snacks", "description": "Chips, cookies, and quick bites"},
        {"id": str(uuid.uuid4()), "name": "Personal Care", "description": "Health and hygiene products"},
        {"id": str(uuid.uuid4()), "name": "Household Items", "description": "Cleaning and home essentials"},
        {"id": str(uuid.uuid4()), "name": "Bakery", "description": "Fresh bread, cakes, and pastries"}
    ]
    await db.categories.insert_many(categories)
    print(f"✅ Created {len(categories)} categories")
    
    # Create sample products
    products = [
        # Groceries
        {"id": str(uuid.uuid4()), "name": "Basmati Rice", "description": "Premium quality basmati rice, 5kg pack", "price": 450.00, "category": "Groceries", "stock": 50, "images": [], "rating": 4.5, "review_count": 23, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Whole Wheat Flour", "description": "100% whole wheat atta, 10kg", "price": 380.00, "category": "Groceries", "stock": 40, "images": [], "rating": 4.3, "review_count": 18, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Sugar", "description": "Pure white sugar, 1kg pack", "price": 45.00, "category": "Groceries", "stock": 100, "images": [], "rating": 4.0, "review_count": 12, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Salt", "description": "Iodized salt, 1kg", "price": 20.00, "category": "Groceries", "stock": 150, "images": [], "rating": 4.2, "review_count": 8, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Cooking Oil", "description": "Refined sunflower oil, 5L", "price": 650.00, "category": "Groceries", "stock": 30, "images": [], "rating": 4.4, "review_count": 15, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Tea Leaves", "description": "Premium Assam tea, 500g", "price": 280.00, "category": "Groceries", "stock": 60, "images": [], "rating": 4.6, "review_count": 31, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Fruits & Vegetables
        {"id": str(uuid.uuid4()), "name": "Fresh Apples", "description": "Kashmiri apples, 1kg", "price": 180.00, "category": "Fruits & Vegetables", "stock": 45, "images": [], "rating": 4.5, "review_count": 25, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Bananas", "description": "Fresh bananas, dozen", "price": 60.00, "category": "Fruits & Vegetables", "stock": 80, "images": [], "rating": 4.3, "review_count": 19, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Tomatoes", "description": "Fresh tomatoes, 1kg", "price": 40.00, "category": "Fruits & Vegetables", "stock": 70, "images": [], "rating": 4.1, "review_count": 14, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Onions", "description": "Red onions, 1kg", "price": 35.00, "category": "Fruits & Vegetables", "stock": 90, "images": [], "rating": 4.0, "review_count": 11, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Potatoes", "description": "Fresh potatoes, 1kg", "price": 30.00, "category": "Fruits & Vegetables", "stock": 100, "images": [], "rating": 4.2, "review_count": 16, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Oranges", "description": "Nagpur oranges, 1kg", "price": 90.00, "category": "Fruits & Vegetables", "stock": 55, "images": [], "rating": 4.6, "review_count": 28, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Dairy Products
        {"id": str(uuid.uuid4()), "name": "Fresh Milk", "description": "Full cream milk, 1L", "price": 60.00, "category": "Dairy Products", "stock": 120, "images": [], "rating": 4.5, "review_count": 42, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Butter", "description": "Unsalted butter, 500g", "price": 280.00, "category": "Dairy Products", "stock": 35, "images": [], "rating": 4.4, "review_count": 21, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Paneer", "description": "Fresh cottage cheese, 200g", "price": 90.00, "category": "Dairy Products", "stock": 40, "images": [], "rating": 4.6, "review_count": 33, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Yogurt", "description": "Fresh curd, 400g", "price": 40.00, "category": "Dairy Products", "stock": 80, "images": [], "rating": 4.3, "review_count": 18, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Beverages
        {"id": str(uuid.uuid4()), "name": "Orange Juice", "description": "Fresh orange juice, 1L", "price": 120.00, "category": "Beverages", "stock": 50, "images": [], "rating": 4.4, "review_count": 27, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Soft Drink", "description": "Cola, 2L bottle", "price": 80.00, "category": "Beverages", "stock": 90, "images": [], "rating": 4.1, "review_count": 15, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Mineral Water", "description": "Packaged drinking water, 1L", "price": 20.00, "category": "Beverages", "stock": 200, "images": [], "rating": 4.0, "review_count": 9, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Coffee", "description": "Instant coffee, 200g", "price": 350.00, "category": "Beverages", "stock": 45, "images": [], "rating": 4.5, "review_count": 38, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Snacks
        {"id": str(uuid.uuid4()), "name": "Potato Chips", "description": "Crispy potato chips, 100g", "price": 40.00, "category": "Snacks", "stock": 85, "images": [], "rating": 4.3, "review_count": 22, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Cookies", "description": "Chocolate chip cookies, 200g", "price": 60.00, "category": "Snacks", "stock": 70, "images": [], "rating": 4.4, "review_count": 29, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Namkeen", "description": "Mixed namkeen, 400g", "price": 120.00, "category": "Snacks", "stock": 55, "images": [], "rating": 4.2, "review_count": 17, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Biscuits", "description": "Cream biscuits, 300g", "price": 50.00, "category": "Snacks", "stock": 95, "images": [], "rating": 4.1, "review_count": 13, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Personal Care
        {"id": str(uuid.uuid4()), "name": "Toothpaste", "description": "Mint fresh toothpaste, 150g", "price": 85.00, "category": "Personal Care", "stock": 100, "images": [], "rating": 4.3, "review_count": 24, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Soap", "description": "Moisturizing soap bar, 125g", "price": 40.00, "category": "Personal Care", "stock": 120, "images": [], "rating": 4.2, "review_count": 19, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Shampoo", "description": "Hair shampoo, 400ml", "price": 220.00, "category": "Personal Care", "stock": 60, "images": [], "rating": 4.5, "review_count": 35, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Face Wash", "description": "Deep cleansing face wash, 100ml", "price": 180.00, "category": "Personal Care", "stock": 50, "images": [], "rating": 4.4, "review_count": 26, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Household Items
        {"id": str(uuid.uuid4()), "name": "Detergent", "description": "Washing powder, 2kg", "price": 280.00, "category": "Household Items", "stock": 45, "images": [], "rating": 4.3, "review_count": 21, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Dish Soap", "description": "Dishwashing liquid, 750ml", "price": 150.00, "category": "Household Items", "stock": 70, "images": [], "rating": 4.2, "review_count": 16, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Floor Cleaner", "description": "Disinfectant floor cleaner, 1L", "price": 180.00, "category": "Household Items", "stock": 55, "images": [], "rating": 4.4, "review_count": 23, "created_at": datetime.now(timezone.utc).isoformat()},
        
        # Bakery
        {"id": str(uuid.uuid4()), "name": "White Bread", "description": "Fresh white bread loaf", "price": 35.00, "category": "Bakery", "stock": 60, "images": [], "rating": 4.2, "review_count": 14, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Whole Wheat Bread", "description": "Healthy whole wheat bread", "price": 45.00, "category": "Bakery", "stock": 55, "images": [], "rating": 4.4, "review_count": 18, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Cake", "description": "Chocolate cake, 500g", "price": 320.00, "category": "Bakery", "stock": 20, "images": [], "rating": 4.6, "review_count": 31, "created_at": datetime.now(timezone.utc).isoformat()},
        {"id": str(uuid.uuid4()), "name": "Pastries", "description": "Assorted pastries, pack of 4", "price": 180.00, "category": "Bakery", "stock": 8, "images": [], "rating": 4.5, "review_count": 25, "created_at": datetime.now(timezone.utc).isoformat()},
    ]
    await db.products.insert_many(products)
    print(f"✅ Created {len(products)} sample products")
    
    print("\n🎉 Database seeding completed successfully!")
    print("\n📝 Login Credentials:")
    print("   Admin: admin@freshmart.com / admin123")
    print("   User:  user@test.com / user123")

if __name__ == "__main__":
    asyncio.run(seed_data())
