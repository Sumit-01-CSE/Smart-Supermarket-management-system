import { useState, useEffect, createContext, useContext } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import axios from 'axios';
import '@/App.css';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Auth Context
const AuthContext = createContext(null);

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      fetchUser();
    } else {
      setLoading(false);
    }
  }, [token]);

  const fetchUser = async () => {
    try {
      const response = await axios.get(`${API}/auth/me`);
      setUser(response.data);
    } catch (error) {
      console.error('Failed to fetch user:', error);
      logout();
    } finally {
      setLoading(false);
    }
  };

  const login = (token, userData) => {
    localStorage.setItem('token', token);
    setToken(token);
    setUser(userData);
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

const useAuth = () => useContext(AuthContext);

// Cart Context
const CartContext = createContext(null);

const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
    toast.success('Added to cart!');
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.id !== productId));
    toast.success('Removed from cart');
  };

  const updateQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart, cartTotal, cartCount }}>
      {children}
    </CartContext.Provider>
  );
};

const useCart = () => useContext(CartContext);

// ==================== AUTH PAGES ====================

const AuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ email: '', password: '', name: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const endpoint = isLogin ? '/auth/login' : '/auth/register';
      const response = await axios.post(`${API}${endpoint}`, formData);
      
      login(response.data.access_token, response.data.user);
      toast.success(isLogin ? 'Welcome back!' : 'Account created successfully!');
      
      if (response.data.user.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/home');
      }
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page" data-testid="auth-page">
      <div className="auth-container">
        <div className="auth-box">
          <div className="auth-header">
            <h1 data-testid="auth-title">{isLogin ? 'Welcome Back' : 'Create Account'}</h1>
            <p>Your favorite supermarket, now online</p>
          </div>

          <form onSubmit={handleSubmit} className="auth-form" data-testid="auth-form">
            {!isLogin && (
              <div className="form-group">
                <label>Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  data-testid="name-input"
                />
              </div>
            )}

            <div className="form-group">
              <label>Email</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                data-testid="email-input"
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <input
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                data-testid="password-input"
              />
            </div>

            {!isLogin && (
              <div className="form-group">
                <label>Phone (Optional)</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  data-testid="phone-input"
                />
              </div>
            )}

            <button type="submit" className="btn-primary" disabled={loading} data-testid="submit-button">
              {loading ? 'Please wait...' : isLogin ? 'Login' : 'Sign Up'}
            </button>
          </form>

          <div className="auth-toggle">
            <p>
              {isLogin ? "Don't have an account?" : 'Already have an account?'}
              <button onClick={() => setIsLogin(!isLogin)} data-testid="toggle-auth">
                {isLogin ? 'Sign Up' : 'Login'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// ==================== CUSTOMER PAGES ====================

const CustomerNav = () => {
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  return (
    <nav className="customer-nav" data-testid="customer-nav">
      <div className="nav-container">
        <h1 className="nav-logo" onClick={() => navigate('/home')} data-testid="nav-logo">FreshMart</h1>
        
        <div className="nav-links">
          <button onClick={() => navigate('/home')} data-testid="nav-home">Home</button>
          <button onClick={() => navigate('/shop')} data-testid="nav-shop">Shop</button>
          <button onClick={() => navigate('/cart')} className="cart-btn" data-testid="nav-cart">
            Cart {cartCount > 0 && <span className="cart-badge" data-testid="cart-count">{cartCount}</span>}
          </button>
          <button onClick={() => navigate('/orders')} data-testid="nav-orders">Orders</button>
          <button onClick={() => navigate('/profile')} data-testid="nav-profile">Profile</button>
          <button onClick={logout} className="btn-logout" data-testid="nav-logout">Logout</button>
        </div>
      </div>
    </nav>
  );
};

const HomePage = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();
  const { addToCart } = useCart();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [productsRes, categoriesRes] = await Promise.all([
        axios.get(`${API}/products?limit=8`),
        axios.get(`${API}/categories`)
      ]);
      setFeaturedProducts(productsRes.data);
      setCategories(categoriesRes.data);
    } catch (error) {
      toast.error('Failed to load data');
    }
  };

  return (
    <div className="home-page" data-testid="home-page">
      <CustomerNav />
      
      <section className="hero-section">
        <div className="hero-content">
          <h1 data-testid="hero-title">Fresh Groceries Delivered to Your Door</h1>
          <p>Quality products at great prices</p>
          <button className="btn-hero" onClick={() => navigate('/shop')} data-testid="shop-now-btn">
            Shop Now
          </button>
        </div>
      </section>

      <section className="categories-section">
        <h2 data-testid="categories-title">Shop by Category</h2>
        <div className="categories-grid">
          {categories.map(category => (
            <div
              key={category.id}
              className="category-card"
              onClick={() => navigate(`/shop?category=${category.name}`)}
              data-testid={`category-${category.name}`}
            >
              <h3>{category.name}</h3>
              <p>{category.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="featured-section">
        <h2 data-testid="featured-title">Featured Products</h2>
        <div className="products-grid">
          {featuredProducts.map(product => (
            <div key={product.id} className="product-card" data-testid={`product-${product.id}`}>
              {product.images[0] && (
                <img src={`${BACKEND_URL}${product.images[0]}`} alt={product.name} />
              )}
              <h3>{product.name}</h3>
              <p className="product-price" data-testid={`price-${product.id}`}>₹{product.price.toFixed(2)}</p>
              <div className="product-actions">
                <button
                  className="btn-primary"
                  onClick={() => addToCart(product)}
                  data-testid={`add-cart-${product.id}`}
                >
                  Add to Cart
                </button>
                <button
                  className="btn-secondary"
                  onClick={() => navigate(`/product/${product.id}`)}
                  data-testid={`view-${product.id}`}
                >
                  View
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const ShopPage = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [minRating, setMinRating] = useState('');
  const navigate = useNavigate();
  const { addToCart } = useCart();

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [search, selectedCategory, minPrice, maxPrice, minRating]);

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${API}/categories`);
      setCategories(response.data);
    } catch (error) {
      console.error('Failed to fetch categories');
    }
  };

  const fetchProducts = async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (selectedCategory) params.append('category', selectedCategory);
      if (minPrice) params.append('min_price', minPrice);
      if (maxPrice) params.append('max_price', maxPrice);
      if (minRating) params.append('min_rating', minRating);

      const response = await axios.get(`${API}/products?${params}`);
      setProducts(response.data);
    } catch (error) {
      toast.error('Failed to load products');
    }
  };

  return (
    <div className="shop-page" data-testid="shop-page">
      <CustomerNav />
      
      <div className="shop-container">
        <aside className="filters-sidebar" data-testid="filters-sidebar">
          <h2>Filters</h2>
          
          <div className="filter-group">
            <label>Search</label>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search products..."
              data-testid="search-input"
            />
          </div>

          <div className="filter-group">
            <label>Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              data-testid="category-filter"
            >
              <option value="">All Categories</option>
              {categories.map(cat => (
                <option key={cat.id} value={cat.name}>{cat.name}</option>
              ))}
            </select>
          </div>

          <div className="filter-group">
            <label>Price Range</label>
            <div className="price-inputs">
              <input
                type="number"
                placeholder="Min"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                data-testid="min-price-input"
              />
              <input
                type="number"
                placeholder="Max"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                data-testid="max-price-input"
              />
            </div>
          </div>

          <div className="filter-group">
            <label>Minimum Rating</label>
            <select
              value={minRating}
              onChange={(e) => setMinRating(e.target.value)}
              data-testid="rating-filter"
            >
              <option value="">Any Rating</option>
              <option value="4">4+ Stars</option>
              <option value="3">3+ Stars</option>
              <option value="2">2+ Stars</option>
            </select>
          </div>

          <button
            className="btn-secondary"
            onClick={() => {
              setSearch('');
              setSelectedCategory('');
              setMinPrice('');
              setMaxPrice('');
              setMinRating('');
            }}
            data-testid="clear-filters-btn"
          >
            Clear Filters
          </button>
        </aside>

        <div className="products-section">
          <h2 data-testid="products-count">{products.length} Products Found</h2>
          
          <div className="products-grid">
            {products.map(product => (
              <div key={product.id} className="product-card" data-testid={`product-${product.id}`}>
                {product.images[0] && (
                  <img src={`${BACKEND_URL}${product.images[0]}`} alt={product.name} />
                )}
                <h3>{product.name}</h3>
                <p className="product-category">{product.category}</p>
                <div className="product-rating" data-testid={`rating-${product.id}`}>
                  {'⭐'.repeat(Math.round(product.rating))} {product.rating.toFixed(1)}
                </div>
                <p className="product-price" data-testid={`price-${product.id}`}>₹{product.price.toFixed(2)}</p>
                <p className="product-stock">Stock: {product.stock}</p>
                <div className="product-actions">
                  <button
                    className="btn-primary"
                    onClick={() => addToCart(product)}
                    disabled={product.stock === 0}
                    data-testid={`add-cart-${product.id}`}
                  >
                    {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
                  </button>
                  <button
                    className="btn-secondary"
                    onClick={() => navigate(`/product/${product.id}`)}
                    data-testid={`view-${product.id}`}
                  >
                    View
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const ProductDetailPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [quantity, setQuantity] = useState(1);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const { addToCart } = useCart();
  const { user } = useAuth();

  useEffect(() => {
    fetchProduct();
    fetchReviews();
  }, [id]);

  const fetchProduct = async () => {
    try {
      const response = await axios.get(`${API}/products/${id}`);
      setProduct(response.data);
    } catch (error) {
      toast.error('Product not found');
    }
  };

  const fetchReviews = async () => {
    try {
      const response = await axios.get(`${API}/reviews/${id}`);
      setReviews(response.data);
    } catch (error) {
      console.error('Failed to fetch reviews');
    }
  };

  const handleAddReview = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/reviews`, {
        product_id: id,
        ...newReview
      });
      toast.success('Review added!');
      setNewReview({ rating: 5, comment: '' });
      fetchReviews();
      fetchProduct();
    } catch (error) {
      toast.error('Failed to add review');
    }
  };

  if (!product) return <div>Loading...</div>;

  return (
    <div className="product-detail-page" data-testid="product-detail-page">
      <CustomerNav />
      
      <div className="product-detail-container">
        <div className="product-images">
          {product.images[0] && (
            <img src={`${BACKEND_URL}${product.images[0]}`} alt={product.name} data-testid="product-image" />
          )}
        </div>

        <div className="product-info">
          <h1 data-testid="product-name">{product.name}</h1>
          <p className="product-category">{product.category}</p>
          <div className="product-rating" data-testid="product-rating">
            {'⭐'.repeat(Math.round(product.rating))} {product.rating.toFixed(1)} ({product.review_count} reviews)
          </div>
          <h2 className="product-price" data-testid="product-price">₹{product.price.toFixed(2)}</h2>
          <p className="product-stock" data-testid="product-stock">Stock: {product.stock} available</p>
          <p className="product-description" data-testid="product-description">{product.description}</p>

          <div className="quantity-selector">
            <label>Quantity:</label>
            <input
              type="number"
              min="1"
              max={product.stock}
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
              data-testid="quantity-input"
            />
          </div>

          <button
            className="btn-primary btn-large"
            onClick={() => addToCart(product, quantity)}
            disabled={product.stock === 0}
            data-testid="add-to-cart-btn"
          >
            {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
          </button>
        </div>
      </div>

      <div className="reviews-section">
        <h2 data-testid="reviews-title">Customer Reviews</h2>
        
        {user && (
          <form onSubmit={handleAddReview} className="review-form" data-testid="review-form">
            <h3>Write a Review</h3>
            <div className="form-group">
              <label>Rating</label>
              <select
                value={newReview.rating}
                onChange={(e) => setNewReview({ ...newReview, rating: parseInt(e.target.value) })}
                data-testid="review-rating-select"
              >
                <option value="5">5 Stars</option>
                <option value="4">4 Stars</option>
                <option value="3">3 Stars</option>
                <option value="2">2 Stars</option>
                <option value="1">1 Star</option>
              </select>
            </div>
            <div className="form-group">
              <label>Comment</label>
              <textarea
                value={newReview.comment}
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                required
                data-testid="review-comment-input"
              />
            </div>
            <button type="submit" className="btn-primary" data-testid="submit-review-btn">
              Submit Review
            </button>
          </form>
        )}

        <div className="reviews-list">
          {reviews.map(review => (
            <div key={review.id} className="review-card" data-testid={`review-${review.id}`}>
              <div className="review-header">
                <strong>{review.user_name}</strong>
                <span>{'⭐'.repeat(review.rating)}</span>
              </div>
              <p>{review.comment}</p>
              <small>{new Date(review.created_at).toLocaleDateString()}</small>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Import useParams
import { useParams } from 'react-router-dom';

const CartPage = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal, clearCart } = useCart();
  const navigate = useNavigate();

  if (cart.length === 0) {
    return (
      <div className="cart-page" data-testid="cart-page">
        <CustomerNav />
        <div className="empty-cart" data-testid="empty-cart">
          <h2>Your cart is empty</h2>
          <button className="btn-primary" onClick={() => navigate('/shop')} data-testid="continue-shopping-btn">
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page" data-testid="cart-page">
      <CustomerNav />
      
      <div className="cart-container">
        <h1 data-testid="cart-title">Shopping Cart</h1>
        
        <div className="cart-items">
          {cart.map(item => (
            <div key={item.id} className="cart-item" data-testid={`cart-item-${item.id}`}>
              {item.images?.[0] && (
                <img src={`${BACKEND_URL}${item.images[0]}`} alt={item.name} />
              )}
              <div className="cart-item-info">
                <h3>{item.name}</h3>
                <p className="cart-item-price" data-testid={`item-price-${item.id}`}>₹{item.price.toFixed(2)}</p>
              </div>
              <div className="cart-item-controls">
                <input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                  data-testid={`quantity-${item.id}`}
                />
                <button
                  className="btn-danger"
                  onClick={() => removeFromCart(item.id)}
                  data-testid={`remove-${item.id}`}
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="cart-summary">
          <h2>Order Summary</h2>
          <div className="summary-row">
            <span>Subtotal:</span>
            <span data-testid="cart-subtotal">₹{cartTotal.toFixed(2)}</span>
          </div>
          <div className="summary-row">
            <span>Shipping:</span>
            <span>₹50.00</span>
          </div>
          <div className="summary-row total">
            <span>Total:</span>
            <span data-testid="cart-total">₹{(cartTotal + 50).toFixed(2)}</span>
          </div>
          <button
            className="btn-primary btn-large"
            onClick={() => navigate('/checkout')}
            data-testid="proceed-checkout-btn"
          >
            Proceed to Checkout
          </button>
          <button
            className="btn-secondary"
            onClick={clearCart}
            data-testid="clear-cart-btn"
          >
            Clear Cart
          </button>
        </div>
      </div>
    </div>
  );
};

const CheckoutPage = () => {
  const { cart, cartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    address: '',
    city: '',
    state: '',
    pincode: '',
    phone: '',
    paymentMethod: 'cod'
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const orderData = {
        items: cart.map(item => ({
          product_id: item.id,
          product_name: item.name,
          price: item.price,
          quantity: item.quantity
        })),
        total: cartTotal + 50,
        shipping_address: {
          address: formData.address,
          city: formData.city,
          state: formData.state,
          pincode: formData.pincode,
          phone: formData.phone
        },
        payment_method: formData.paymentMethod
      };

      await axios.post(`${API}/orders`, orderData);
      toast.success('Order placed successfully!');
      clearCart();
      navigate('/orders');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="checkout-page" data-testid="checkout-page">
      <CustomerNav />
      
      <div className="checkout-container">
        <h1 data-testid="checkout-title">Checkout</h1>
        
        <div className="checkout-content">
          <form onSubmit={handleSubmit} className="checkout-form" data-testid="checkout-form">
            <h2>Shipping Address</h2>
            
            <div className="form-group">
              <label>Address</label>
              <textarea
                required
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                data-testid="address-input"
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>City</label>
                <input
                  type="text"
                  required
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  data-testid="city-input"
                />
              </div>
              <div className="form-group">
                <label>State</label>
                <input
                  type="text"
                  required
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  data-testid="state-input"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Pincode</label>
                <input
                  type="text"
                  required
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                  data-testid="pincode-input"
                />
              </div>
              <div className="form-group">
                <label>Phone</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  data-testid="phone-input"
                />
              </div>
            </div>

            <h2>Payment Method</h2>
            <div className="payment-methods">
              <label className="payment-option">
                <input
                  type="radio"
                  name="payment"
                  value="cod"
                  checked={formData.paymentMethod === 'cod'}
                  onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                  data-testid="payment-cod"
                />
                Cash on Delivery
              </label>
              <label className="payment-option">
                <input
                  type="radio"
                  name="payment"
                  value="card"
                  checked={formData.paymentMethod === 'card'}
                  onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                  data-testid="payment-card"
                />
                Card Payment (Mock)
              </label>
            </div>

            <button type="submit" className="btn-primary btn-large" disabled={loading} data-testid="place-order-btn">
              {loading ? 'Placing Order...' : 'Place Order'}
            </button>
          </form>

          <div className="order-summary">
            <h2>Order Summary</h2>
            {cart.map(item => (
              <div key={item.id} className="summary-item" data-testid={`summary-item-${item.id}`}>
                <span>{item.name} x {item.quantity}</span>
                <span>₹{(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            <div className="summary-row">
              <span>Subtotal:</span>
              <span>₹{cartTotal.toFixed(2)}</span>
            </div>
            <div className="summary-row">
              <span>Shipping:</span>
              <span>₹50.00</span>
            </div>
            <div className="summary-row total">
              <span>Total:</span>
              <span data-testid="order-total">₹{(cartTotal + 50).toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await axios.get(`${API}/orders`);
      setOrders(response.data);
    } catch (error) {
      toast.error('Failed to load orders');
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      pending: 'orange',
      processing: 'blue',
      shipped: 'purple',
      delivered: 'green',
      cancelled: 'red'
    };
    return colors[status] || 'gray';
  };

  return (
    <div className="orders-page" data-testid="orders-page">
      <CustomerNav />
      
      <div className="orders-container">
        <h1 data-testid="orders-title">My Orders</h1>
        
        {orders.length === 0 ? (
          <div className="empty-orders" data-testid="empty-orders">
            <p>No orders yet</p>
          </div>
        ) : (
          <div className="orders-list">
            {orders.map(order => (
              <div key={order.id} className="order-card" data-testid={`order-${order.id}`}>
                <div className="order-header">
                  <h3>Order #{order.id.slice(0, 8)}</h3>
                  <span
                    className="order-status"
                    style={{ backgroundColor: getStatusColor(order.status) }}
                    data-testid={`order-status-${order.id}`}
                  >
                    {order.status.toUpperCase()}
                  </span>
                </div>
                <p className="order-date">{new Date(order.created_at).toLocaleDateString()}</p>
                <div className="order-items">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="order-item" data-testid={`order-item-${idx}`}>
                      <span>{item.product_name} x {item.quantity}</span>
                      <span>₹{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <div className="order-total" data-testid={`order-total-${order.id}`}>
                  <strong>Total: ₹{order.total.toFixed(2)}</strong>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const ProfilePage = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    name: user?.name || '',
    phone: user?.phone || ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${API}/users/profile`, formData);
      toast.success('Profile updated!');
    } catch (error) {
      toast.error('Failed to update profile');
    }
  };

  return (
    <div className="profile-page" data-testid="profile-page">
      <CustomerNav />
      
      <div className="profile-container">
        <h1 data-testid="profile-title">My Profile</h1>
        
        <form onSubmit={handleSubmit} className="profile-form" data-testid="profile-form">
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={user?.email} disabled data-testid="profile-email" />
          </div>

          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              data-testid="profile-name-input"
            />
          </div>

          <div className="form-group">
            <label>Phone</label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              data-testid="profile-phone-input"
            />
          </div>

          <button type="submit" className="btn-primary" data-testid="update-profile-btn">
            Update Profile
          </button>
        </form>
      </div>
    </div>
  );
};

// ==================== ADMIN PAGES ====================

const AdminNav = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="admin-layout">
      <aside className="admin-sidebar" data-testid="admin-sidebar">
        <h1 className="admin-logo" data-testid="admin-logo">FreshMart Admin</h1>
        <nav className="admin-nav">
          <button onClick={() => navigate('/admin')} data-testid="admin-nav-dashboard">Dashboard</button>
          <button onClick={() => navigate('/admin/products')} data-testid="admin-nav-products">Products</button>
          <button onClick={() => navigate('/admin/users')} data-testid="admin-nav-users">Users</button>
          <button onClick={() => navigate('/admin/orders')} data-testid="admin-nav-orders">Orders</button>
          <button onClick={() => navigate('/admin/categories')} data-testid="admin-nav-categories">Categories</button>
          <button onClick={logout} className="btn-logout" data-testid="admin-nav-logout">Logout</button>
        </nav>
      </aside>
    </div>
  );
};

const AdminDashboard = () => {
  const [analytics, setAnalytics] = useState(null);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${API}/analytics/dashboard`);
      setAnalytics(response.data);
    } catch (error) {
      toast.error('Failed to load analytics');
    }
  };

  if (!analytics) return <div>Loading...</div>;

  return (
    <div className="admin-page" data-testid="admin-dashboard">
      <AdminNav />
      <div className="admin-content">
        <h1 data-testid="dashboard-title">Dashboard Overview</h1>
        
        <div className="stats-grid">
          <div className="stat-card" data-testid="stat-users">
            <h3>Total Users</h3>
            <p className="stat-value">{analytics.total_users}</p>
          </div>
          <div className="stat-card" data-testid="stat-products">
            <h3>Total Products</h3>
            <p className="stat-value">{analytics.total_products}</p>
          </div>
          <div className="stat-card" data-testid="stat-orders">
            <h3>Total Orders</h3>
            <p className="stat-value">{analytics.total_orders}</p>
          </div>
          <div className="stat-card" data-testid="stat-revenue">
            <h3>Total Revenue</h3>
            <p className="stat-value">₹{analytics.total_revenue.toFixed(2)}</p>
          </div>
        </div>

        <div className="dashboard-sections">
          <section className="low-stock-section">
            <h2 data-testid="low-stock-title">Low Stock Products</h2>
            <div className="products-list">
              {analytics.low_stock_products.map(product => (
                <div key={product.id} className="product-item" data-testid={`low-stock-${product.id}`}>
                  <span>{product.name}</span>
                  <span className="stock-warning">Stock: {product.stock}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="recent-orders-section">
            <h2 data-testid="recent-orders-title">Recent Orders</h2>
            <div className="orders-list">
              {analytics.recent_orders.map(order => (
                <div key={order.id} className="order-item" data-testid={`recent-order-${order.id}`}>
                  <span>Order #{order.id.slice(0, 8)}</span>
                  <span>{order.status}</span>
                  <span>₹{order.total.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

const AdminProducts = () => {
  const [products, setProducts] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    stock: ''
  });
  const [imageFiles, setImageFiles] = useState([]);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get(`${API}/products`);
      setProducts(response.data);
    } catch (error) {
      toast.error('Failed to load products');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const form = new FormData();
    form.append('name', formData.name);
    form.append('description', formData.description);
    form.append('price', formData.price);
    form.append('category', formData.category);
    form.append('stock', formData.stock);
    
    imageFiles.forEach(file => {
      form.append('images', file);
    });

    try {
      if (editingProduct) {
        await axios.put(`${API}/products/${editingProduct.id}`, form);
        toast.success('Product updated!');
      } else {
        await axios.post(`${API}/products`, form);
        toast.success('Product created!');
      }
      
      setShowForm(false);
      setEditingProduct(null);
      setFormData({ name: '', description: '', price: '', category: '', stock: '' });
      setImageFiles([]);
      fetchProducts();
    } catch (error) {
      toast.error('Failed to save product');
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      category: product.category,
      stock: product.stock
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    
    try {
      await axios.delete(`${API}/products/${id}`);
      toast.success('Product deleted');
      fetchProducts();
    } catch (error) {
      toast.error('Failed to delete product');
    }
  };

  return (
    <div className="admin-page" data-testid="admin-products">
      <AdminNav />
      <div className="admin-content">
        <div className="page-header">
          <h1 data-testid="products-title">Products Management</h1>
          <button
            className="btn-primary"
            onClick={() => {
              setShowForm(!showForm);
              setEditingProduct(null);
              setFormData({ name: '', description: '', price: '', category: '', stock: '' });
            }}
            data-testid="add-product-btn"
          >
            {showForm ? 'Cancel' : 'Add Product'}
          </button>
        </div>

        {showForm && (
          <form onSubmit={handleSubmit} className="admin-form" data-testid="product-form">
            <div className="form-group">
              <label>Name</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                data-testid="product-name-input"
              />
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                data-testid="product-description-input"
              />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label>Price (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  data-testid="product-price-input"
                />
              </div>
              <div className="form-group">
                <label>Stock</label>
                <input
                  type="number"
                  required
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  data-testid="product-stock-input"
                />
              </div>
            </div>
            <div className="form-group">
              <label>Category</label>
              <input
                type="text"
                required
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                data-testid="product-category-input"
              />
            </div>
            <div className="form-group">
              <label>Images</label>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={(e) => setImageFiles(Array.from(e.target.files))}
                data-testid="product-images-input"
              />
            </div>
            <button type="submit" className="btn-primary" data-testid="save-product-btn">
              {editingProduct ? 'Update Product' : 'Create Product'}
            </button>
          </form>
        )}

        <div className="products-table">
          <table data-testid="products-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map(product => (
                <tr key={product.id} data-testid={`product-row-${product.id}`}>
                  <td>{product.name}</td>
                  <td>{product.category}</td>
                  <td>₹{product.price.toFixed(2)}</td>
                  <td>{product.stock}</td>
                  <td>
                    <button
                      className="btn-secondary"
                      onClick={() => handleEdit(product)}
                      data-testid={`edit-product-${product.id}`}
                    >
                      Edit
                    </button>
                    <button
                      className="btn-danger"
                      onClick={() => handleDelete(product.id)}
                      data-testid={`delete-product-${product.id}`}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const AdminUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get(`${API}/users`);
      setUsers(response.data);
    } catch (error) {
      toast.error('Failed to load users');
    }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      await axios.put(`${API}/users/${userId}/role?role=${newRole}`);
      toast.success('User role updated');
      fetchUsers();
    } catch (error) {
      toast.error('Failed to update role');
    }
  };

  return (
    <div className="admin-page" data-testid="admin-users">
      <AdminNav />
      <div className="admin-content">
        <h1 data-testid="users-title">Users Management</h1>
        
        <div className="users-table">
          <table data-testid="users-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id} data-testid={`user-row-${user.id}`}>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>{user.role}</td>
                  <td>
                    {user.role === 'user' ? (
                      <button
                        className="btn-primary"
                        onClick={() => handleRoleChange(user.id, 'admin')}
                        data-testid={`promote-user-${user.id}`}
                      >
                        Promote to Admin
                      </button>
                    ) : (
                      <button
                        className="btn-secondary"
                        onClick={() => handleRoleChange(user.id, 'user')}
                        data-testid={`demote-user-${user.id}`}
                      >
                        Demote to User
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await axios.get(`${API}/orders`);
      setOrders(response.data);
    } catch (error) {
      toast.error('Failed to load orders');
    }
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      await axios.put(`${API}/orders/${orderId}/status?status=${newStatus}`);
      toast.success('Order status updated');
      fetchOrders();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  return (
    <div className="admin-page" data-testid="admin-orders">
      <AdminNav />
      <div className="admin-content">
        <h1 data-testid="orders-title">Orders Management</h1>
        
        <div className="orders-table">
          <table data-testid="orders-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Date</th>
                <th>Total</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.id} data-testid={`order-row-${order.id}`}>
                  <td>#{order.id.slice(0, 8)}</td>
                  <td>{new Date(order.created_at).toLocaleDateString()}</td>
                  <td>₹{order.total.toFixed(2)}</td>
                  <td>
                    <select
                      value={order.status}
                      onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      data-testid={`order-status-${order.id}`}
                    >
                      <option value="pending">Pending</option>
                      <option value="processing">Processing</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                  <td>
                    <button className="btn-secondary" data-testid={`view-order-${order.id}`}>
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const AdminCategories = () => {
  const [categories, setCategories] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '' });

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${API}/categories`);
      setCategories(response.data);
    } catch (error) {
      toast.error('Failed to load categories');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/categories`, formData);
      toast.success('Category created!');
      setShowForm(false);
      setFormData({ name: '', description: '' });
      fetchCategories();
    } catch (error) {
      toast.error('Failed to create category');
    }
  };

  return (
    <div className="admin-page" data-testid="admin-categories">
      <AdminNav />
      <div className="admin-content">
        <div className="page-header">
          <h1 data-testid="categories-title">Categories Management</h1>
          <button
            className="btn-primary"
            onClick={() => setShowForm(!showForm)}
            data-testid="add-category-btn"
          >
            {showForm ? 'Cancel' : 'Add Category'}
          </button>
        </div>

        {showForm && (
          <form onSubmit={handleSubmit} className="admin-form" data-testid="category-form">
            <div className="form-group">
              <label>Name</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                data-testid="category-name-input"
              />
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                data-testid="category-description-input"
              />
            </div>
            <button type="submit" className="btn-primary" data-testid="save-category-btn">
              Create Category
            </button>
          </form>
        )}

        <div className="categories-grid">
          {categories.map(category => (
            <div key={category.id} className="category-card" data-testid={`category-${category.id}`}>
              <h3>{category.name}</h3>
              <p>{category.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ==================== PROTECTED ROUTES ====================

const ProtectedRoute = ({ children, adminOnly = false }) => {
  const { user, loading } = useAuth();

  if (loading) return <div>Loading...</div>;

  if (!user) return <Navigate to="/" />;

  if (adminOnly && user.role !== 'admin') return <Navigate to="/home" />;

  return children;
};

// ==================== MAIN APP ====================

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <div className="App">
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<AuthPage />} />
              
              {/* Customer Routes */}
              <Route path="/home" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
              <Route path="/shop" element={<ProtectedRoute><ShopPage /></ProtectedRoute>} />
              <Route path="/product/:id" element={<ProtectedRoute><ProductDetailPage /></ProtectedRoute>} />
              <Route path="/cart" element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
              <Route path="/checkout" element={<ProtectedRoute><CheckoutPage /></ProtectedRoute>} />
              <Route path="/orders" element={<ProtectedRoute><OrdersPage /></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
              
              {/* Admin Routes */}
              <Route path="/admin" element={<ProtectedRoute adminOnly><AdminDashboard /></ProtectedRoute>} />
              <Route path="/admin/products" element={<ProtectedRoute adminOnly><AdminProducts /></ProtectedRoute>} />
              <Route path="/admin/users" element={<ProtectedRoute adminOnly><AdminUsers /></ProtectedRoute>} />
              <Route path="/admin/orders" element={<ProtectedRoute adminOnly><AdminOrders /></ProtectedRoute>} />
              <Route path="/admin/categories" element={<ProtectedRoute adminOnly><AdminCategories /></ProtectedRoute>} />
            </Routes>
          </BrowserRouter>
          <Toaster position="top-right" />
        </div>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;