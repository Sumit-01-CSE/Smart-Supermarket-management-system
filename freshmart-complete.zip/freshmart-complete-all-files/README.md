# FreshMart - Supermarket Management System

A comprehensive, professional-grade supermarket management system built with React, FastAPI, and MongoDB. Features beautiful UI with smooth animations, role-based access control, and complete e-commerce functionality.

![FreshMart Logo](https://img.shields.io/badge/FreshMart-Supermarket-10b981?style=for-the-badge)

## 🌟 Features

### Customer Features
- **User Authentication**: Secure login/signup with JWT tokens
- **Product Browsing**: Browse 35+ products across 8 categories
- **Advanced Search & Filters**: 
  - Search by product name
  - Filter by category
  - Price range filtering
  - Minimum rating filter
- **Shopping Cart**: Add/remove items, update quantities
- **Checkout Process**: Complete order flow with shipping details
- **Order Tracking**: View order history with status updates
- **Product Reviews**: Rate and review products
- **User Profile**: Manage personal information

### Admin Features
- **Dashboard Analytics**: 
  - Total users, products, orders, revenue
  - Low stock alerts
  - Recent orders tracking
- **Product Management**: Full CRUD operations with image upload
- **User Management**: Promote/demote admin roles
- **Order Management**: Update order status (pending → delivered)
- **Category Management**: Create and manage product categories
- **Inventory Tracking**: Monitor stock levels

## 🛠️ Tech Stack

### Frontend
- **React 19.0** - UI framework
- **React Router v7** - Navigation
- **Axios** - HTTP client
- **Tailwind CSS** - Styling
- **Shadcn UI** - Component library
- **Sonner** - Toast notifications

### Backend
- **FastAPI** - Python web framework
- **MongoDB** - Database (Motor async driver)
- **JWT** - Authentication
- **Bcrypt** - Password hashing
- **Python Multipart** - File uploads

## 📁 Project Structure

```
freshmart-supermarket-system/
├── backend/
│   ├── server.py              # Main FastAPI application
│   ├── seed_data.py           # Database seeding script
│   ├── requirements.txt       # Python dependencies
│   ├── .env                   # Environment variables
│   └── static/uploads/        # Product images
│
└── frontend/
    ├── src/
    │   ├── App.js             # Main React component (all pages)
    │   ├── App.css            # Styles with animations
    │   ├── index.js           # Entry point
    │   └── components/ui/     # Shadcn UI components
    ├── public/
    ├── package.json
    ├── tailwind.config.js
    └── .env
```

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v16+)
- Python (v3.9+)
- MongoDB (v4.0+)
- Yarn package manager

### Backend Setup

1. **Navigate to backend directory:**
```bash
cd backend
```

2. **Create virtual environment:**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies:**
```bash
pip install -r requirements.txt
```

4. **Configure environment variables (.env):**
```
MONGO_URL=mongodb://localhost:27017
DB_NAME=supermarket_db
CORS_ORIGINS=*
SECRET_KEY=your-secret-key-change-in-production
```

5. **Seed the database:**
```bash
python seed_data.py
```

6. **Run the backend server:**
```bash
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

Backend will be available at: `http://localhost:8001`

### Frontend Setup

1. **Navigate to frontend directory:**
```bash
cd frontend
```

2. **Install dependencies:**
```bash
yarn install
```

3. **Configure environment variables (.env):**
```
REACT_APP_BACKEND_URL=http://localhost:8001
```

4. **Start the development server:**
```bash
yarn start
```

Frontend will be available at: `http://localhost:3000`

## 👥 Default Login Credentials

### Admin Account
- **Email:** admin@freshmart.com
- **Password:** admin123

### Customer Account
- **Email:** user@test.com
- **Password:** user123

## 📦 Database Schema

### Collections

**users**
```javascript
{
  id: UUID,
  email: String,
  password: String (hashed),
  name: String,
  role: "user" | "admin",
  phone: String,
  addresses: Array,
  wishlist: Array,
  created_at: DateTime
}
```

**products**
```javascript
{
  id: UUID,
  name: String,
  description: String,
  price: Number,
  category: String,
  stock: Number,
  images: Array,
  rating: Number,
  review_count: Number,
  created_at: DateTime
}
```

**orders**
```javascript
{
  id: UUID,
  user_id: UUID,
  items: Array,
  total: Number,
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled",
  shipping_address: Object,
  payment_method: String,
  created_at: DateTime
}
```

**categories**
```javascript
{
  id: UUID,
  name: String,
  description: String,
  image: String
}
```

**reviews**
```javascript
{
  id: UUID,
  product_id: UUID,
  user_id: UUID,
  user_name: String,
  rating: Number (1-5),
  comment: String,
  created_at: DateTime
}
```

## 🎨 Features Details

### Authentication
- JWT-based secure authentication
- Role-based access control (Customer/Admin)
- Protected routes
- Automatic token refresh

### Product Catalog
- 8 Categories: Groceries, Fruits & Vegetables, Dairy Products, Beverages, Snacks, Personal Care, Household Items, Bakery
- 35 pre-loaded products with realistic pricing (₹20 - ₹650)
- Star ratings and review counts
- Stock management

### Shopping Experience
- Persistent cart (localStorage)
- Real-time cart updates
- Stock validation before checkout
- Multiple payment methods (COD, Card)
- Order confirmation

### Admin Dashboard
- Real-time analytics
- Low stock alerts
- Revenue tracking
- Order status management

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user

### Products
- `GET /api/products` - List products (with filters)
- `GET /api/products/{id}` - Get product details
- `POST /api/products` - Create product (admin)
- `PUT /api/products/{id}` - Update product (admin)
- `DELETE /api/products/{id}` - Delete product (admin)

### Orders
- `GET /api/orders` - List orders
- `POST /api/orders` - Create order
- `PUT /api/orders/{id}/status` - Update order status (admin)

### Categories
- `GET /api/categories` - List categories
- `POST /api/categories` - Create category (admin)

### Users
- `GET /api/users` - List users (admin)
- `PUT /api/users/{id}/role` - Update user role (admin)
- `PUT /api/users/profile` - Update profile

### Reviews
- `GET /api/reviews/{product_id}` - Get product reviews
- `POST /api/reviews` - Add review

### Analytics
- `GET /api/analytics/dashboard` - Get dashboard stats (admin)

## 🎭 UI Components

### Shadcn UI Components Used
- Button, Card, Badge
- Input, Textarea, Select
- Dialog, Alert Dialog
- Toast (Sonner)
- Accordion, Tabs
- And 40+ more components

### Custom Animations
- Fade-in effects on page load
- Scale transforms on hover
- Smooth slide transitions
- Gradient animations
- Skeleton loaders
- Cart badge pulse

## 🎯 Key Highlights

✅ **Production Ready**: Clean code, proper error handling
✅ **Responsive Design**: Works on mobile, tablet, desktop
✅ **Modern UI**: Beautiful gradient backgrounds, smooth animations
✅ **Security**: JWT tokens, password hashing, input validation
✅ **Performance**: Lazy loading, code splitting, optimized images
✅ **Scalable**: Modular architecture, easy to extend

## 📝 Currency

All prices are in **Indian Rupees (₹)**

## 🐛 Troubleshooting

### MongoDB Connection Error
```bash
# Ensure MongoDB is running
sudo systemctl start mongodb
```

### Port Already in Use
```bash
# Backend (port 8001)
lsof -ti:8001 | xargs kill -9

# Frontend (port 3000)
lsof -ti:3000 | xargs kill -9
```

### Module Not Found Errors
```bash
# Backend
pip install -r requirements.txt

# Frontend
rm -rf node_modules
yarn install
```

## 🔮 Future Enhancements

- Real payment gateway integration (Stripe/Razorpay)
- Email notifications
- WhatsApp order updates
- Advanced analytics with charts
- Product recommendations
- Wishlist functionality
- Multi-language support
- Dark mode
- Progressive Web App (PWA)
- Mobile app (React Native)

## 📄 License

This project is created for educational purposes.

## 👨‍💻 Author

Built with ❤️ by Emergent AI Agent

## 🙏 Acknowledgments

- Shadcn UI for beautiful components
- Tailwind CSS for utility-first styling
- FastAPI for the amazing Python framework
- MongoDB for flexible database solution

---

**⭐ If you find this project helpful, please consider giving it a star!**

For issues and feature requests, please create an issue in the repository.
